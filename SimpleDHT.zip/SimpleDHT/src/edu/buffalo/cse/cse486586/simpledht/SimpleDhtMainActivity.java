package edu.buffalo.cse.cse486586.simpledht;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.TextView;

public class SimpleDhtMainActivity extends Activity {
	static int emulator_instance;
	final String localHost="10.0.2.2";
	private ContentResolver mContentResolver;
    private Uri mUri;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_simple_dht_main);
        
        
        Context c=getApplicationContext();
    	String [] files=c.fileList();
    	for(String f:files)
    	{
    		c.deleteFile(f);
    	}
        
        
        TelephonyManager tel = (TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE);
    	String portStr = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);
    	emulator_instance=Integer.parseInt(portStr);
    	mUri = buildUri("content", "edu.buffalo.cse.cse486586.simpledht.provider");
    	mContentResolver=getContentResolver();
        TextView tv = (TextView) findViewById(R.id.textView1);
        tv.setMovementMethod(new ScrollingMovementMethod());
        findViewById(R.id.button3).setOnClickListener(
                new OnTestClickListener(tv, getContentResolver()));
    }
    private Uri buildUri(String scheme, String authority) {
        Uri.Builder uriBuilder = new Uri.Builder();
        uriBuilder.authority(authority);
        uriBuilder.scheme(scheme);
        return uriBuilder.build();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.activity_simple_dht_main, menu);
        return true;
    }
    public void lDumpDisplay(View v)
    {
    	Cursor cc=getContentResolver().query(mUri, null, "LDump", null, null);
    	TextView tv = (TextView) findViewById(R.id.textView1);
    	if(cc!=null)
    	{
    		if((cc.moveToFirst())){
    		do{
    		int keyIndex = cc.getColumnIndex("key");
			int valueIndex = cc.getColumnIndex("value");
			//cc.moveToFirst();
			Log.v("printing", "values");
			//cc.moveToLast();
			String key=cc.getString(keyIndex);
			String value=cc.getString(valueIndex);
			tv.append(key+":"+value+"\n");
			//cc.moveToNext();
    		}while(cc.moveToNext());
    		}
    		}

    	
    	/*Context c=getApplicationContext();
    	String [] files=c.fileList();
    	for(String f:files)
    	{
    		Cursor cc=getContentResolver().query(mUri, null, f, null, null);
    		TextView tv = (TextView) findViewById(R.id.textView1);
			int keyIndex = cc.getColumnIndex("key");
			int valueIndex = cc.getColumnIndex("value");
			cc.moveToFirst();
			//cc.moveToLast();
			String key=cc.getString(keyIndex);
			String value=cc.getString(valueIndex);
			tv.append(key+":"+value+"/n");
			//
    	}*/
    	//System.out.println("local dump");
    }
    public void gDumpDisplay(View v)
    {
    	Cursor cc=getContentResolver().query(mUri, null, "GDump", null, null);
    	TextView tv = (TextView) findViewById(R.id.textView1);
    	if(cc!=null)
    	{
    		if((cc.moveToFirst())){
    		do{
    		int keyIndex = cc.getColumnIndex("key");
			int valueIndex = cc.getColumnIndex("value");
			//cc.moveToFirst();
			Log.v("printing", "values");
			//cc.moveToLast();
			String key=cc.getString(keyIndex);
			String value=cc.getString(valueIndex);
			tv.append(key+":"+value+"\n");
			//cc.moveToNext();
    		}while(cc.moveToNext());
    		}
    		}
        /*Context c=getApplicationContext();
    	String [] files=c.fileList();
    	for(String f:files)
    	{
    		c.deleteFile(f);
    	}
    	System.out.println("global dump");*/
    }
}
