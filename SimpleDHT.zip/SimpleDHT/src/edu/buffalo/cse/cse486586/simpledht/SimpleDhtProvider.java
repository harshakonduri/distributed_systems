package edu.buffalo.cse.cse486586.simpledht;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Formatter;
import java.util.TreeMap;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.telephony.TelephonyManager;
import android.util.Log;

public class SimpleDhtProvider extends ContentProvider {
	public static final String AUTHORITY = "edu.buffalo.cse.cse486586.simpledht.provider";
	public static final Uri CONTENT_URI = Uri.parse("content://" + AUTHORITY);
	private int emulator_instance;
	final String localHost="10.0.2.2";
	MatrixCursor mc=null;
    private Uri mUri;
	static TreeMap<String,Integer> currentNodes;
	boolean breaktheLoopNow=false;
	boolean queryWait = false;
	public static int predecessor,succcessor;

	private static final UriMatcher match=new UriMatcher(UriMatcher.NO_MATCH);
	static
	{
		//match.addURI(AUTHORITY, "*", 1);
		match.addURI(AUTHORITY, null, 1);
		//match.addURI(AUTHORITY, "#", 1);
	}
    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        // TODO Auto-generated method stub
        return 0;
    }
    private Uri buildUri(String scheme, String authority) {
        Uri.Builder uriBuilder = new Uri.Builder();
        uriBuilder.authority(authority);
        uriBuilder.scheme(scheme);
        return uriBuilder.build();
    }
    @Override
    public String getType(Uri uri) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {

		try 
		{
    	String fileName,insFile=values.getAsString("key");
    	fileName = genHash(insFile); 
		String valueInFile=values.getAsString("value");
		String predHash=genHash(predecessor+"");
		String succHash=genHash(succcessor+"");
		String yourHash=genHash(emulator_instance+"");
    	boolean belongsToThisNode = ((fileName.compareTo(predHash) > 0) && (fileName.compareTo(yourHash) <= 0));
    	boolean isSmallest = ( predHash.compareTo(yourHash) > 0 );
    	boolean upperBoundaryCase =  (fileName.compareTo(predHash) > 0);
    	boolean lowerBoundaryCase = ( fileName.compareTo(yourHash) < 0 );

			


				if(predecessor==0 && succcessor ==0)
				{
					//System.out.println(emulator_instance);
					Context c=getContext();
					int u=match.match(uri);
					switch(u)
					{
					case 1:
					try {
						//System.out.println("opening file");
						FileOutputStream fos=c.openFileOutput(insFile,Context.MODE_PRIVATE);
						
						fos.write(valueInFile.getBytes());
					
						fos.close();
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					break;
					default:
						break;
					}

				}		
				else if(belongsToThisNode || (isSmallest && (lowerBoundaryCase || upperBoundaryCase)))
				{
			//Log.v("Transfer File", "In insert after transfer start");
				Log.v("Insert Here", "Key = "+insFile+"value = "+valueInFile);
			Context c=getContext();
			int u=match.match(uri);
			switch(u)
			{
			case 1:
			try {
				//System.out.println("opening file");
				FileOutputStream fos=c.openFileOutput(insFile,Context.MODE_PRIVATE);
				
				fos.write(valueInFile.getBytes());
			
				fos.close();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
			default:
				break;
			}
			//System.out.println("123");
			}
		else
		{
			Log.v("Transfer File", "Sending to Successor");
			String message="Insert:"+values.getAsString("key")+":"+values.getAsString("value");
			sendPredSucc(succcessor,message);
		}
		}
    	catch (NoSuchAlgorithmException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return uri;

    }

    @Override
    public boolean onCreate() {
		TelephonyManager tel = (TelephonyManager) getContext().getSystemService(Context.TELEPHONY_SERVICE);
    	String portStr = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);
    	emulator_instance=Integer.parseInt(portStr);
    	mUri = buildUri("content", "edu.buffalo.cse.cse486586.simpledht.provider");
		if(emulator_instance == 5554)
		{
			currentNodes=new TreeMap<String, Integer>();
		}
		createServer();
		//emulator_instance=SimpleDhtMainActivity.emulator_instance;
		nodeJoin(emulator_instance);
		
		return true;
    }

    private void nodeJoin(int emulator_instance2) {
		if(emulator_instance2 == 5554)
		{
			try {
				currentNodes.put(genHash(emulator_instance2+""),emulator_instance2);
				Log.v("Simple Dht", "Adding 5554 to Current Nodes"+currentNodes.size());
			} catch (NoSuchAlgorithmException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else
		{
			System.out.println("Join Request");
			Log.v("SIMPLE DHT", "Join Request"+emulator_instance2);
			sendJoinRequest("Join:"+emulator_instance2);
		}
		
	}

	private void createServer() 
	{
		new Thread(new Runnable()
		{
			public void run()
			{
				try 
				{
					ServerSocket s = new ServerSocket(10000);
					while(true)
					{
						Socket ss=s.accept();
						String msg_ServerSide=null;
						BufferedReader br=new BufferedReader(new InputStreamReader(ss.getInputStream()));
						msg_ServerSide=br.readLine();
						//System.out.println(Integer.parseInt(msg_ServerSide));
						// check if we received a join request
					String [] s_msgs=msg_ServerSide.split(":");
						if(s_msgs[0].equals("Join"))
						{
							String substring=s_msgs[1];//msg_ServerSide.substring(4);
							//System.out.println(Integer.parseInt(substring)+"----------");
							Log.v("Simple Dht", "Received Join request at 5554");
							//Add the incoming node to the tree map;	
							if(emulator_instance == 5554)
							{
								
							currentNodes.put(genHash(substring), Integer.parseInt(substring));
							Log.v("Simple Dht", "Adding to Current Nodes"+currentNodes.size());
							//Update respective predeccessors and successors
							updatePredSucc(substring);
							}
						}
						else if(s_msgs[0].equals("Pred"))
						{
						
							//String [] presuc=msg_ServerSide.split(":");
							predecessor=Integer.parseInt(s_msgs[1]);
							succcessor=Integer.parseInt(s_msgs[3]);
							System.out.println("Pred:"+predecessor+"and Succ is:"+succcessor);
							Log.v("Predecessor Successor Update", "Received P"+predecessor+"Received S"+succcessor);
							//sendJoinRequest("Dist:"+succcessor);
							//sendPredSucc(predecessor, "Dist");
						//	sendPredSucc(succcessor, "Dist"); // uncomment for key value redistribution among nodes for new join
						//	transferFiles();
						}
						else if(s_msgs[0].equals("Insert"))
						{
							Log.v("Insert Message", "Insert files request");
							//String message=msg_ServerSide.substring(6);
							ContentValues cv=new ContentValues();
							cv.put("key", s_msgs[1]);
							cv.put("value", s_msgs[2]);
							
							insert(mUri, cv);
						}
						else if(s_msgs[0].equals("GDUMP"))
						{
							Log.v("GDUMP next",msg_ServerSide);
						if(s_msgs[1].equals(emulator_instance+""))//did the message return back to us??
						{
							Log.v("GDump","Break the Loop");
							breaktheLoopNow=true;
						}
						else
						{
							respondWithString(s_msgs[1]);
							Log.v("GDUMP Sending to ", "Successor "+succcessor);
							Log.v("Compare Emulators", s_msgs[1]+" "+emulator_instance);
							sendPredSucc(succcessor, msg_ServerSide);
						}
						}
						else if(s_msgs[0].equals("GResponse"))
						{
							Log.v("GResponse", s_msgs[1]);
							String [] setOfFiles = s_msgs[1].split("\\#");
							for(String subFile: setOfFiles)
							{
								String [] fileKV = subFile.split("\\*");
								mc.addRow(fileKV);
							}
						}
						else if(s_msgs[0].equals("Query"))
						{
							Log.v("Query next",msg_ServerSide);
						if(s_msgs[1].equals(emulator_instance+""))//did the message return back to us??
						{
							Log.v("Query","Break the Loop");
							queryWait=true;
						}
						else
						{
							//respondWithString(s_msgs[1]);
							if(!checkInSelf(s_msgs[2]))
							{
							Log.v("Query Sending to ", "Successor "+succcessor);
							Log.v("Compare Emulators", s_msgs[1]+" "+emulator_instance);
							sendPredSucc(succcessor, msg_ServerSide);
							}
							else
							{
								respondSingleString(s_msgs[1],s_msgs[2]);
							}
						}
						}
						else if(s_msgs[0].equals("QueryResponse"))
						{
							String [] fileKV = s_msgs[1].split("\\*");
							mc.addRow(fileKV);
							queryWait=true;
						}
						/* Uncommant for key-value redistribution for new node join
						 * else if(msg_ServerSide.substring(0, 4).equals("Dist"))
						{
							Log.v("Distribution of Files reqeust","received at "+emulator_instance);
							transferFiles();
						}
						*/
						br.close();
						ss.close();
					}
				} catch (IOException e) 
				{
					e.printStackTrace();
				} catch (NumberFormatException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (NoSuchAlgorithmException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}



			private void respondWithString(String string) {
				
				Log.v("Gdump", "Sending String to required Destination");
				Context c=getContext();
				StringBuffer result=new StringBuffer("GResponse:");
				String [] files=getContext().fileList();				
				for(String file:files)
				{
					String op=null;
					try {
					FileInputStream fis=c.openFileInput(file);
					byte [] b=new byte[fis.available()];
					
						while((fis.read(b)) != -1)
						{
							
						}
						op=new String(b);
						result.append(file+"*"+op+"#");
						fis.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				sendPredSucc(Integer.parseInt(string), result.toString());
			}
private void respondSingleString(String string,String sel) {
				
				Log.v("Gdump", "Sending String to required Destination");
				Context c=getContext();
				StringBuffer result=new StringBuffer("QueryResponse:");
				String [] files=getContext().fileList();				
				for(String file:files)
				{
					if(file.equals(sel))
					{
					String op=null;
					try {
					FileInputStream fis=c.openFileInput(file);
					byte [] b=new byte[fis.available()];
					
						while((fis.read(b)) != -1)
						{
							
						}
						op=new String(b);
						result.append(file+"*"+op);
						fis.close();
						sendPredSucc(Integer.parseInt(string), result.toString());
						return;
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					}
				}
				
			}
/*	 Uncomment for new node join redistribution
 * 		private void transferFiles() {
				Log.v("Transfer File", "Initiating Transfeer");
				Context c=getContext();
				String [] files=getContext().fileList();				
				for(String file:files)
				{
					String op=null;
					ContentValues cv = new ContentValues();
					try {
					FileInputStream fis=c.openFileInput(file);
					byte [] b=new byte[fis.available()];
					
						while((fis.read(b)) != -1)
						{
							
						}
						op=new String(b);
						fis.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					cv.put("key",file);
					cv.put("value", op);
					c.deleteFile(file);
					insert(CONTENT_URI, cv);
				}
				
			}
*/
			
		}).start();
		
	}
	private boolean checkInSelf(String selection) {
		
		try
		{
		String fileName,insFile=selection;
    	fileName = genHash(insFile); 
		String predHash=genHash(predecessor+"");
		String succHash=genHash(succcessor+"");
		String yourHash=genHash(emulator_instance+"");
    	boolean belongsToThisNode = ((fileName.compareTo(predHash) > 0) && (fileName.compareTo(yourHash) <= 0));
    	boolean isSmallest = ( predHash.compareTo(yourHash) > 0 );
    	boolean upperBoundaryCase =  (fileName.compareTo(predHash) > 0);
    	boolean lowerBoundaryCase = ( fileName.compareTo(yourHash) < 0 );
		String [] sar=new String[2];
		MatrixCursor m=new MatrixCursor(new String[]{"key","value"});
	
		if(belongsToThisNode || (isSmallest && (lowerBoundaryCase || upperBoundaryCase)))
		{
			return true;
		}
		else
		{
			return false;
		}
		}
		catch(NoSuchAlgorithmException nse)
		{		
		}
		return false;
	}
	private void updatePredSucc(String substring) throws NoSuchAlgorithmException
	{
		Log.v("Sending P & S updates:", "from"+emulator_instance+" here");
		String message=null;
		switch(currentNodes.size())
		{
		case 1:
			// Only 1 node is active and alive so pred and succ are not defined.
			predecessor=0;
			succcessor=0;
			break;
		case 2:
			// 2 nodes are alive and active, so update pred and succ with incoming node and send back the same for node to update
			predecessor=Integer.parseInt(substring);
			succcessor=Integer.parseInt(substring);
			message="Pred:"+5554+":Succ:"+5554;
			sendPredSucc(Integer.parseInt(substring),message);
			break;
		default:
			break;
		}
		if(currentNodes.size() > 2)
		{
		String pres = updateAllNodePredSucc(substring);
			// now update the predecessors and successors of the new nodes predecessors and successors
		String []updateNeighbours = pres.split(":");
		for(String emu:updateNeighbours)
		{
			updateAllNodePredSucc(emu);
		}
		}
		
	}
	private String updateAllNodePredSucc(String substring) throws NoSuchAlgorithmException
	{
		System.out.println("Updating the Predecessors and Successors of "+substring);
		String message,ret;
		if(currentNodes.lowerKey(genHash(substring))!=null && currentNodes.higherKey(genHash(substring))!=null)
		{
			String pred=currentNodes.lowerKey(genHash(substring));
			int pre=currentNodes.get(pred);
			String succ=currentNodes.higherKey(genHash(substring));
			int suc=currentNodes.get(succ);
			message="Pred:"+pre+":Succ:"+suc;
			sendPredSucc(Integer.parseInt(substring),message);
			 ret=pre+":"+suc;
			return ret;

		}
		else
		{
			//check if you are the lower most key in the tree map
			if(currentNodes.lowerKey(genHash(substring))==null)
			{
				String pred=currentNodes.lastKey();
				int pre=currentNodes.get(pred);
				String succ=currentNodes.higherKey(genHash(substring));
				int suc=currentNodes.get(succ);
				message="Pred:"+pre+":Succ:"+suc;
				sendPredSucc(Integer.parseInt(substring),message);
				 ret=pre+":"+suc;
				return ret;

			}
			else if(currentNodes.higherKey(genHash(substring))==null) // chck if you are the highest key in tree map
			{
				String pred=currentNodes.lowerKey(genHash(substring));
				int pre=currentNodes.get(pred);
				String succ=currentNodes.firstKey();
				int suc=currentNodes.get(succ);
				message="Pred:"+pre+":Succ:"+suc;
				sendPredSucc(Integer.parseInt(substring),message);
				 ret=pre+":"+suc;
				return ret;

			}
		}
		return null;
	}
	@Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs,
            String sortOrder) {
		// TODO Auto-generated method stub
		if(selection.equals("GDump"))
		{
			mc=new MatrixCursor(new String[]{"key","value"});
			addMyFiles();
			if(succcessor != 0)
			{
			String message="GDUMP"+":"+emulator_instance;
    		sendPredSucc(succcessor, message);//(message);
			while(!breaktheLoopNow)
			{
				
			}
			breaktheLoopNow=false;
			}
    		return mc;
		}
		else if(selection.equals("LDump"))
		{
			mc=new MatrixCursor(new String[]{"key","value"});
			addMyFiles();
			return mc;
		}
		else
		{
			String fileName=selection;
			String [] sar=new String[2];
			MatrixCursor m=new MatrixCursor(new String[]{"key","value"});
			mc=new MatrixCursor(new String[]{"key","value"});
			if(checkInSelf(selection) || succcessor == 0)
			{
		Context c=getContext();
		String op=null;
		int u=match.match(uri);
		switch(u)
		{
		case 1:
		try {
			FileInputStream fis=c.openFileInput(fileName);
			byte [] b=new byte[fis.available()];
			while((fis.read(b)) != -1)
			{
				
			}
			op=new String(b);
			fis.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		break;
		default:
			break;
		}			
		sar[0]=selection;
		sar[1]=op;
		m.addRow(sar);
		return m;
			}
			else
			{
				String message="Query"+":"+emulator_instance+":"+selection;
				sendPredSucc(succcessor, message);
				while(!queryWait)
				{
					
				}
				queryWait=false;
				return mc;
			}
			}
		}
    
// add my files to matrix cursor
    private void addMyFiles() {
		// TODO Auto-generated method stub
	Context c=getContext();
	String [] files=c.fileList();
	for(String file:files)
	{
		String op=null;
		try {
		FileInputStream fis=c.openFileInput(file);
		byte [] b=new byte[fis.available()];
		
			while((fis.read(b)) != -1)
			{
				
			}
			op=new String(b);
			fis.close();
			mc.addRow(new String[]{file,op});
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
    }
	@Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        // TODO Auto-generated method stub
        return 0;
    }
    private String genHash(String input) throws NoSuchAlgorithmException {
        MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
        byte[] sha1Hash = sha1.digest(input.getBytes());
        Formatter formatter = new Formatter();
        for (byte b : sha1Hash) {
            formatter.format("%02x", b);
        }
        return formatter.toString();
    }
    private void sendJoinRequest(final String message) 
	{
	new Thread(new Runnable()
	{
		public void run()
		{
			Socket s=null;
			try {
				s=new Socket(localHost,11108);
				sendandUpdate(s,message);
				s.close();
			} catch (UnknownHostException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}


	}).start();	
				
	}
    private void sendPredSucc(final int emulatorInstance,final String message) 
	{
	new Thread(new Runnable()
	{
		public void run()
		{
			Socket s=null;
			try {
				if(emulatorInstance == 5556)
				{
				s=new Socket(localHost,11112);
				sendandUpdate(s,message);
				s.close();
				}
				else if(emulatorInstance == 5558)
				{
					s=new Socket(localHost,11116);
					sendandUpdate(s,message);
					s.close();
				}
				else if(emulatorInstance == 5554)
				{
					s=new Socket(localHost,11108);
					sendandUpdate(s,message);
					s.close();
				}
			} catch (UnknownHostException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}


	}).start();					
	}
	
    private void sendandUpdate(Socket s, String message) throws IOException 
	{
		PrintWriter pw = new PrintWriter(s.getOutputStream());
		pw.println(message);
		pw.close();
		s.close();
	}
}
