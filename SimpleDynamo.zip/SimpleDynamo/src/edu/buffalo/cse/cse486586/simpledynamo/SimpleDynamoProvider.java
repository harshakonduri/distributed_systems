package edu.buffalo.cse.cse486586.simpledynamo;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Formatter;
import java.util.Set;
import java.util.TreeMap;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.telephony.TelephonyManager;
import android.util.Log;

public class SimpleDynamoProvider extends ContentProvider {
	public static final String AUTHORITY = "edu.buffalo.cse.cse486586.simpledynamo.provider";
	public static final Uri CONTENT_URI = Uri.parse("content://" + AUTHORITY);
	private int emulator_instance;
	final String localHost="10.0.2.2";
	MatrixCursor mc=null;
    private Uri mUri;
    long start_time,current_time;
    private boolean isStore=false;
	static TreeMap<String,Integer> currentNodes;
	boolean breaktheLoopNow=false;
	boolean queryWait = false;
	private boolean recv_ack=false;
	protected boolean isFailed;
	static int versionCheck=0;
	static int versionCount=99;
	static String outputValueResponse;
	protected boolean resp_received=true;
	protected boolean verSuccess=true;
	public static int predecessor,succcessor,successor2;
	
	private static final UriMatcher match=new UriMatcher(UriMatcher.NO_MATCH);
	static
	{
		//match.addURI(AUTHORITY, "*", 1);
		match.addURI(AUTHORITY, null, 1);
		//match.addURI(AUTHORITY, "#", 1);
	}
    private Uri buildUri(String scheme, String authority) {
        Uri.Builder uriBuilder = new Uri.Builder();
        uriBuilder.authority(authority);
        uriBuilder.scheme(scheme);
        return uriBuilder.build();
    }
	@Override
	public int delete(Uri uri, String selection, String[] selectionArgs) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String getType(Uri uri) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Uri insert(Uri uri, ContentValues values) {
    	String fileName,insFile=values.getAsString("key");
    	int shouldUpdate=0;
    	try {
			fileName = genHash(insFile);
		
		String valueInFile=values.getAsString("value");
	/*	String predHash=genHash(predecessor+"");
		String succHash=genHash(succcessor+"");
		String yourHash=genHash(emulator_instance+"");
    	boolean belongsToThisNode = ((fileName.compareTo(predHash) > 0) && (fileName.compareTo(yourHash) <= 0));
    	boolean isSmallest = ( predHash.compareTo(yourHash) > 0 );
    	boolean upperBoundaryCase =  (fileName.compareTo(predHash) > 0);
    	boolean lowerBoundaryCase = ( fileName.compareTo(yourHash) < 0 );
    	
    	if(belongsToThisNode || (isSmallest && (lowerBoundaryCase || upperBoundaryCase)))
		{*/
		
		
		if(isStore || checkInSelf(emulator_instance+"",insFile) || isFailed)
		{
	//Log.v("Transfer File", "In insert after transfer start");
			if(!isStore)
				Log.v("Insert Here", "Key = "+insFile+"value = "+valueInFile);
			else
				Log.v("Store Here", "Key = "+insFile+"value = "+valueInFile);		
	Context c=getContext();
	int u=match.match(uri);
	switch(u)
	{
	case 1:
	try {
		////System.out.println("opening file");
		boolean b = isFileAvailable(insFile);
		String val=valueInFile;
	if(!isStore)
	{
		if(b)
		{
			Log.v("version upgrade", insFile+"----file available");
			String op=null;
			try {
			FileInputStream fis=c.openFileInput(insFile);
			byte [] by=new byte[fis.available()];
			
				while((fis.read(by)) != -1)
				{
					
				}
				op=new String(by);
				//read existing file.
				String [] ver_arr=op.split(",");
				int i=0;
				//if(ver_arr.length > 1)
				//{
					i=Integer.parseInt(ver_arr[1]);
					shouldUpdate = validateVersion(i,val);
				//}
				/*else
				{
					shouldUpdate = 2;
				}*/		 
				if(shouldUpdate == 2)
				{	
				i++;
				val=val+","+i; // increment the version and store.
				}
				else if(shouldUpdate == 1)
				{
					//write the file as it is.
				}
				Log.v("version upgrade", val+"----value");
				fis.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else
		{
			val=val+","+1;
			shouldUpdate = 2;
		}
	}
			if(shouldUpdate !=0 || isStore)
			{	
				FileOutputStream fos=c.openFileOutput(insFile,Context.MODE_WORLD_WRITEABLE);
				fos.write(val.getBytes());
				fos.close();
			}
		if(!isStore)
		{
			String message="Store:"+values.getAsString("key")+":"+val+":"+emulator_instance;
			Log.v("Store message from"+emulator_instance, " to"+succcessor+" and "+successor2);
			sendPredSucc(succcessor,message);
			/*try {
				Thread.sleep(400);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			if(recv_ack)
			{
				recv_ack = false;
			}
			else
			{
				int []succ = updatePredSucc(succcessor+"");
				String m1="InsertFail:"+values.getAsString("key")+":"+val+":"+emulator_instance;
				sendPredSucc(succ[1],m1);
			}*/
			sendPredSucc(successor2,message);
			/*try {
				Thread.sleep(400);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			if(recv_ack)
			{
				recv_ack = false;
			}
			else
			{
				int []succ = updatePredSucc(successor2+"");
				String m1="InsertFail:"+values.getAsString("key")+":"+val+":"+emulator_instance;
				sendPredSucc(succ[1],m1);
			}
			*/
		}
		isStore=false;
		isFailed=false;
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	break;
	default:
		break;
	}
	////System.out.println("123");
	
	}
else
{
	int coordinator = getCoordinator(insFile);
	Log.v("Co-ordinator Fwd", "Sending to"+coordinator+" key"+values.getAsString("key")+" value"+values.getAsString("value"));
	String message="Insert:"+values.getAsString("key")+":"+values.getAsString("value")+":"+emulator_instance;
	sendPredSucc(coordinator,message);
	//start_time = System.currentTimeMillis();
	try {
		Thread.sleep(600);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	if(recv_ack)
	{
		Log.v("ACK","Receive the ACK");
		recv_ack = false;
	}
	else
	{
		int []succ = updatePredSucc(coordinator+"");
		String m1="InsertFail:"+values.getAsString("key")+":"+values.getAsString("value")+":"+emulator_instance;
		Log.v("Insert Fail Msg", "Sending to"+succ[1]+" key"+values.getAsString("key")+" value"+values.getAsString("value"));
		sendPredSucc(succ[1],m1);
	}
}
}
catch (NoSuchAlgorithmException e1) {
	// TODO Auto-generated catch block
	e1.printStackTrace();
}
return uri;
	}

	private int validateVersion(int version, String val) {
		String []s =val.split(",");
		if(s.length == 1 )
			return 2; // drop packets.
		int inp_ver=Integer.parseInt(s[1]);
		if(inp_ver > version)
		{
			return 1;//incoming version is greater, just update,
		}
		if(inp_ver <= version)
		{
			return 0;
		}
		return 2; // increment version.
		
	}
	private boolean isFileAvailable(String k) {
		String []s = getContext().fileList();
		if(s.length==0)
			return false;
		for(String key:s)
		{
			if(key.equals(k))
			{
				return true;
			}
		}
		return false;
	}
	private int getCoordinator(String fileName)
	{
		Set<String> ks = currentNodes.keySet();
		for(String s:ks)
		{
			if(checkInSelf(currentNodes.get(s)+"",fileName))
			{
				return currentNodes.get(s);
			}
		}
		return 0;
	}
	@Override
	public boolean onCreate() {
		TelephonyManager tel = (TelephonyManager) getContext().getSystemService(Context.TELEPHONY_SERVICE);
    	String portStr = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);
    	emulator_instance=Integer.parseInt(portStr);
    	mUri = buildUri("content", "edu.buffalo.cse.cse486586.simpledynamo.provider");
		currentNodes=new TreeMap<String, Integer>();
		populateMap();
		createServer();
		//emulator_instance=SimpleDhtMainActivity.emulator_instance;
		//nodeJoin(emulator_instance);
		Context c=getContext();
		String[] files=c.fileList();
		for(int i=0;i<files.length;i++)
		{
		getContext().deleteFile(files[i]);
		}
		String m="Reborn:"+emulator_instance;
		sendPredSucc(succcessor, m);
		return true;
	}

	private void populateMap() {
		try {
			currentNodes.put(genHash("5554"), 5554);
			currentNodes.put(genHash("5556"), 5556);
			currentNodes.put(genHash("5558"), 5558);
			int [] p=updatePredSucc(emulator_instance+"");
			predecessor = p[0];
			succcessor = p[1];
			successor2 = p[0];
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	private int[] updatePredSucc(String substring) throws NoSuchAlgorithmException
	{
		//System.out.println("Updating the Predecessors and Successors of "+substring);
		String message;
		int []ret=new int[2];
		if(currentNodes.lowerKey(genHash(substring))!=null && currentNodes.higherKey(genHash(substring))!=null)
		{
			String pred=currentNodes.lowerKey(genHash(substring));
			int pre=currentNodes.get(pred);
			String succ=currentNodes.higherKey(genHash(substring));
			int suc=currentNodes.get(succ);
			message="Pred:"+pre+":Succ:"+suc;
			sendPredSucc(Integer.parseInt(substring),message);
			 ret[0] = pre; ret[1] = suc;
			return ret;

		}
		else
		{
			//check if you are the lower most key in the tree map
			if(currentNodes.lowerKey(genHash(substring))==null)
			{
				String pred=currentNodes.lastKey();
				int pre=currentNodes.get(pred);
				String succ=currentNodes.higherKey(genHash(substring));
				int suc=currentNodes.get(succ);
				message="Pred:"+pre+":Succ:"+suc;
				sendPredSucc(Integer.parseInt(substring),message);
				ret[0] = pre; ret[1] = suc;
				return ret;
				
			}
			else if(currentNodes.higherKey(genHash(substring))==null) // chck if you are the highest key in tree map
			{
				String pred=currentNodes.lowerKey(genHash(substring));
				int pre=currentNodes.get(pred);
				String succ=currentNodes.firstKey();
				int suc=currentNodes.get(succ);
				message="Pred:"+pre+":Succ:"+suc;
				sendPredSucc(Integer.parseInt(substring),message);
				ret[0] = pre; ret[1] = suc;
				return ret;

			}
		}
		return null;
	}
	private void createServer() 
	{
		new Thread(new Runnable()
		{
			public void run()
			{
				try 
				{
					ServerSocket s = new ServerSocket(10000);
					while(true)
					{
						Socket ss=s.accept();
						String msg_ServerSide=null;
						BufferedReader br=new BufferedReader(new InputStreamReader(ss.getInputStream()));
						msg_ServerSide=br.readLine();
						////System.out.println(Integer.parseInt(msg_ServerSide));
						// check if we received a join request
					String [] s_msgs=msg_ServerSide.split(":");
						/*if(s_msgs[0].equals("Join"))
						{
							String substring=s_msgs[1];//msg_ServerSide.substring(4);
							////System.out.println(Integer.parseInt(substring)+"----------");
							Log.v("Simple Dht", "Received Join request at 5554");
							//Add the incoming node to the tree map;	

						}*/
						if(s_msgs[0].equals("Store"))
						{
							//String msg = "Ack"+":"+emulator_instance;
							//sendPredSucc(Integer.parseInt(s_msgs[3]), msg);
							Log.v("Store Message", "Store file");
							ContentValues cv=new ContentValues();
							cv.put("key", s_msgs[1]);
							cv.put("value", s_msgs[2]);
							isStore = true;
							insert(mUri, cv);
							
						}
						else if(s_msgs[0].equals("Insert"))
						{
							String msg = "Ack"+":"+emulator_instance;
							sendPredSucc(Integer.parseInt(s_msgs[3]), msg);
							Log.v("Insert Message", "Insert files request");
							ContentValues cv=new ContentValues();
							cv.put("key", s_msgs[1]);
							cv.put("value", s_msgs[2]);
							insert(mUri, cv);
						}
						else if(s_msgs[0].equals("InsertFail"))
						{
							//insertProvider(mUri,s_msgs[1],s_msgs[2]);
							isFailed=true;
							ContentValues cv=new ContentValues();
							cv.put("key", s_msgs[1]);
							cv.put("value", s_msgs[2]);
							insert(mUri, cv);
						}
						else if(s_msgs[0].equals("Ack"))
						{
						recv_ack = true;
						}
						else if(s_msgs[0].equals("Reborn"))
						{
							Log.v("Reborn", "Transfeer");
							giveBackFiles(s_msgs[1]);
						}
						else if(s_msgs[0].equals("Rebirth_Gift"))
						{
							insertProvider(mUri,s_msgs[1],s_msgs[2]);
						}
						else if(s_msgs[0].equals("GetRequest"))
						{
							reqHandler(s_msgs);
						}
						else if(s_msgs[0].equals("VersionUpdateRequest"))
						{
							Log.v("Ver Req","from"+s_msgs[1]);
							int ver = getVotes(s_msgs[2]);
							Log.v("Ver Req","version is "+ver);
							String mess="UpdatedVersion:"+ver;
							sendPredSucc(Integer.parseInt(s_msgs[1]), mess);
						}
						else if(s_msgs[0].equals("UpdatedVersion"))
						{
							int ver = Integer.parseInt(s_msgs[1]);
							Log.v("Updated Version","Incoming Version is ="+ver+"Our version is = "+versionCheck);
							if(ver == versionCheck)
							{
								
								versionCount++;
								Log.v("Incoming Version","version = "+ver+"version count ="+versionCount);
							}
						}
						else if(s_msgs[0].equals("Success"))
						{
							Log.v("Success","key="+s_msgs[1]+"value="+s_msgs[2]);
							String [] res=new String[2];
						/*	if(s_msgs[1]==null || s_msgs[2]==null)
							{
								boolean b = isFileAvailable(s_msgs[1]);
								if(b)
								{
									Context c = getContext();
									String op=null;
									try 
									{
									FileInputStream fis=c.openFileInput(s_msgs[1]);
									byte [] by=new byte[fis.available()];
									
										while((fis.read(by)) != -1)
										{
											
										}
										op=new String(by);
										String [] var=op.split(",");
										res[0]=s_msgs[1];
										res[1]=var[0];
									}
									catch(IOException e)
									{
										
									}
								}
							}
							else
							{*/
							res[0]=s_msgs[1];
							String []stre=s_msgs[2].split(",");
							res[1]=stre[0];
							//}
							Log.v("Values to cursor are ","Key = "+res[0]+"value ="+res[1]);
							mc.addRow(res);
							resp_received = false;
						}
						/*else if(s_msgs[0].equals("GDUMP"))
						{
							Log.v("GDUMP next",msg_ServerSide);
						if(s_msgs[1].equals(emulator_instance+""))//did the message return back to us??
						{
							Log.v("GDump","Break the Loop");
							breaktheLoopNow=true;
						}
						else
						{
							respondWithString(s_msgs[1]);
							Log.v("GDUMP Sending to ", "Successor "+succcessor);
							Log.v("Compare Emulators", s_msgs[1]+" "+emulator_instance);
							sendPredSucc(succcessor, msg_ServerSide);
						}
						}
						else if(s_msgs[0].equals("GResponse"))
						{
							Log.v("GResponse", s_msgs[1]);
							String [] setOfFiles = s_msgs[1].split("\\#");
							for(String subFile: setOfFiles)
							{
								String [] fileKV = subFile.split("\\*");
								mc.addRow(fileKV);
							}
						}
/*						else if(s_msgs[0].equals("Query"))
						{
							Log.v("Query next",msg_ServerSide);
						if(s_msgs[1].equals(emulator_instance+""))//did the message return back to us??
						{
							Log.v("Query","Break the Loop");
							queryWait=true;
						}
						else
						{
							//respondWithString(s_msgs[1]);
							if(!checkInSelf(s_msgs[2]))
							{
							Log.v("Query Sending to ", "Successor "+succcessor);
							Log.v("Compare Emulators", s_msgs[1]+" "+emulator_instance);
							sendPredSucc(succcessor, msg_ServerSide);
							}
							else
							{
								respondSingleString(s_msgs[1],s_msgs[2]);
							}
						}
						}
						else if(s_msgs[0].equals("QueryResponse"))
						{
							String [] fileKV = s_msgs[1].split("\\*");
							mc.addRow(fileKV);
							queryWait=true;
						}
						/* Uncommant for key-value redistribution for new node join
						 * else if(msg_ServerSide.substring(0, 4).equals("Dist"))
						{
							Log.v("Distribution of Files reqeust","received at "+emulator_instance);
							transferFiles();
						}
						*/
						br.close();
						ss.close();
					}
				} catch (IOException e) 
				{
					e.printStackTrace();
				} catch (NumberFormatException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}



			



			private void reqHandler(final String[] s_msgs) {
				new Thread(new Runnable()
				{
					public void run()
					{
						String msg = "Ack"+":"+emulator_instance;
						sendPredSucc(Integer.parseInt(s_msgs[1]), msg);
						String mess="VersionUpdateRequest:"+emulator_instance+":"+s_msgs[2];
					//	sendPredSucc(succcessor, mess);
					//	sendPredSucc(successor2, mess);
						versionCheck = getVotes(s_msgs[2]);
						versionCount++;
						Log.v("Get Request", "Checked self version"+versionCheck+"versionCount = "+versionCount);
						while(versionCount < 2)
						{
							
						}
						Log.v("Sending Success","to emulator"+s_msgs[1]);
						String resp="Success:"+s_msgs[2]+":"+outputValueResponse;
						sendPredSucc(Integer.parseInt(s_msgs[1]), resp);
					}
				}).start();
				
			}

			private void insertProvider(Uri uri,String insFile,String valueInFile) {
				Context c=getContext();
				int u=match.match(uri);
				switch(u)
				{
				case 1:
					////System.out.println("opening file");
					FileOutputStream fos;
					try {
						fos = c.openFileOutput(insFile,Context.MODE_WORLD_WRITEABLE);
					
					
					fos.write(valueInFile.getBytes());
				
					fos.close();
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				
			}

			}

 		private void giveBackFiles(String emu) {
				
 			
 			
				Context c=getContext();
				String [] files=getContext().fileList();				
				for(String file:files)
				{
					if(checkInSelf(emu, file))
					{
						Log.v("Rebirth request", "Initiating Transfeer");
						String op=null;
						ContentValues cv = new ContentValues();
						try 
						{
						FileInputStream fis=c.openFileInput(file);
						byte [] b=new byte[fis.available()];
						
							while((fis.read(b)) != -1)
							{
								
							}
							op=new String(b);
							fis.close();
						} catch (IOException e) 
						{
							e.printStackTrace();
						}						
						cv.put("key",file);
						cv.put("value", op);
//						c.deleteFile(file);
						String mes="Rebirth_Gift:"+cv.getAsString("key")+":"+cv.getAsString("value")+":"+emulator_instance;
						sendPredSucc(Integer.parseInt(emu), mes);
					}
					else
					{
						String op=null;
						ContentValues cv = new ContentValues();
						try 
						{
						FileInputStream fis=c.openFileInput(file);
						byte [] b=new byte[fis.available()];
						
							while((fis.read(b)) != -1)
							{
								
							}
							op=new String(b);
							fis.close();
						} catch (IOException e) 
						{
							e.printStackTrace();
						}						
						cv.put("key",file);
						cv.put("value", op);
//						c.deleteFile(file);
						String message="Rebirth_Gift:"+cv.getAsString("key")+":"+cv.getAsString("value")+":"+emulator_instance;
						Log.v("Store message from"+emulator_instance, " to"+succcessor+" and "+successor2);
						sendPredSucc(Integer.parseInt(emu),message);
					}
				}
				
				
			}

			
		}).start();
		
	}
	protected int getVotes(String string) {
		int version = 0;
		boolean b = isFileAvailable(string);
		if(b)
		{
			Context c = getContext();
			String op=null;
			try 
			{
			FileInputStream fis=c.openFileInput(string);
			byte [] by=new byte[fis.available()];
			
				while((fis.read(by)) != -1)
				{
					
				}
				op=new String(by);
				//read existing file.
				outputValueResponse = op;
				String [] ver_arr=op.split(",");
				version = Integer.parseInt(ver_arr[1]);
				
			}
			catch(IOException ie)
			{
				ie.printStackTrace();
			}
		}
		
		return version;
	}
	private boolean checkInSelf(String emu,String selection) {
		
		try
		{
		String fileName,insFile=selection;
    	fileName = genHash(insFile); 
    	int [] presucc = updatePredSucc(emu);
		String predHash=genHash(presucc[0]+"");
		String yourHash=genHash(emu);
		Log.v("Check in Self", "Predecessor to"+emu+"is "+presucc[0]);
    	boolean belongsToThisNode = ((fileName.compareTo(predHash) >= 0) && (fileName.compareTo(yourHash) < 0));
    	boolean isSmallest = ( predHash.compareTo(yourHash) > 0 );
    	boolean upperBoundaryCase =  (fileName.compareTo(predHash) > 0);
    	boolean lowerBoundaryCase =  (fileName.compareTo(yourHash) < 0);
	
		if(belongsToThisNode || (isSmallest && (lowerBoundaryCase || upperBoundaryCase)))
		{
			return true;
		}
		else
		{
			return false;
		}
		}
		catch(NoSuchAlgorithmException nse)
		{		
		}
		return false;
	}
	
	@Override
	public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs,
            String sortOrder) {
		// TODO Auto-generated method stub
		if(selection.equals("LDump") || (Integer.parseInt(selection) < 20))
		{
			mc=new MatrixCursor(new String[]{"key","value"});
			addMyFiles();
			return mc;
		}
		else
		{
			resp_received = true;
			mc=new MatrixCursor(new String[]{"key","value"});
			int coordinator = getCoordinator(selection);
			Log.v("Query Coord", "Coordinator is"+coordinator);
			String msg="GetRequest:"+emulator_instance+":"+selection;
			sendPredSucc(coordinator, msg);
			try {
				Thread.sleep(400);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(recv_ack)
			{
				recv_ack = false;
				Log.v("ACK","Ack received");
			}
			else
			{
				try 
				{					
					int []succ = updatePredSucc(coordinator+"");
					Log.v("Query Fail","Sending request to "+succ[1]);
					String m1="GetRequest:"+emulator_instance+":"+selection;
					sendPredSucc(succ[1], m1);
				} catch (NoSuchAlgorithmException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
			}
			while(resp_received)
			{
				
			}

		}

		return mc;		
		}
    
// add my files to matrix cursor
    private void addMyFiles() {
		// TODO Auto-generated method stub
	Context c=getContext();
	String [] files=c.fileList();
	for(String file:files)
	{
		String op=null;
		try {
		FileInputStream fis=c.openFileInput(file);
		byte [] b=new byte[fis.available()];
		
			while((fis.read(b)) != -1)
			{
				
			}
			op=new String(b);
			fis.close();
			mc.addRow(new String[]{file,op});
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
    }

	@Override
	public int update(Uri uri, ContentValues values, String selection,
			String[] selectionArgs) {
		// TODO Auto-generated method stub
		return 0;
	}

    private String genHash(String input) throws NoSuchAlgorithmException {
        MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
        byte[] sha1Hash = sha1.digest(input.getBytes());
        Formatter formatter = new Formatter();
        for (byte b : sha1Hash) {
            formatter.format("%02x", b);
        }
        return formatter.toString();
    }
    
    private void sendPredSucc(final int emulatorInstance,final String message) 
	{
	new Thread(new Runnable()
	{
		public void run()
		{
			Socket s=null;
			try {
				if(emulatorInstance == 5556)
				{
				s=new Socket(localHost,11112);
				sendandUpdate(s,message);
				s.close();
				}
				else if(emulatorInstance == 5558)
				{
					s=new Socket(localHost,11116);
					sendandUpdate(s,message);
					s.close();
				}
				else if(emulatorInstance == 5554)
				{
					s=new Socket(localHost,11108);
					sendandUpdate(s,message);
					s.close();
				}
			} catch (UnknownHostException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}


	}).start();					
	}
	
    private void sendandUpdate(Socket s, String message) throws IOException 
	{
		PrintWriter pw = new PrintWriter(s.getOutputStream());
		pw.println(message);
		pw.close();
		s.close();
	}
}
