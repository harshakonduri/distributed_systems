package edu.buffalo.cse.cse486586.simpledynamo;


import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class SimpleDynamoActivity extends Activity {

	private static final int TEST_CNT = 20;
	private ContentResolver mContentResolver;
	private Uri mUri;
	private String TAG;
	private static final String KEY_FIELD = "key";
	private static final String VALUE_FIELD = "value";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_simple_dynamo);
		mContentResolver = getContentResolver();
		mUri = buildUri("content", "edu.buffalo.cse.cse486586.simpledynamo.provider");
		TextView tv = (TextView) findViewById(R.id.textView1);
        tv.setMovementMethod(new ScrollingMovementMethod());
        Context c=getApplicationContext();
		String[] files=c.fileList();
		for(int i=0;i<files.length;i++)
		{
		getApplicationContext().deleteFile(files[i]);
		}
	}
   
	private Uri buildUri(String scheme, String authority) {
        Uri.Builder uriBuilder = new Uri.Builder();
        uriBuilder.authority(authority);
        uriBuilder.scheme(scheme);
        return uriBuilder.build();
    }
	public void insertToProvider(ContentValues [] conval)
	{
		for(ContentValues c : conval)
		{
			mContentResolver.insert(mUri, c);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	public void lDumpDisplay(View v)
    {
    	Cursor cc=getContentResolver().query(mUri, null, "LDump", null, null);
    	TextView tv = (TextView) findViewById(R.id.textView1);
    	if(cc!=null)
    	{
    		if((cc.moveToFirst())){
    		do{
    		int keyIndex = cc.getColumnIndex("key");
			int valueIndex = cc.getColumnIndex("value");
			//cc.moveToFirst();
			Log.v("printing", "values");
			//cc.moveToLast();
			String key=cc.getString(keyIndex);
			String value=cc.getString(valueIndex);
			String[] var=value.split(",");
			tv.append(key+":"+var[0]+"\n");
			//cc.moveToNext();
    		}while(cc.moveToNext());
    		}
    		}

    	
    	/*Context c=getApplicationContext();
    	String [] files=c.fileList();
    	for(String f:files)
    	{
    		Cursor cc=getContentResolver().query(mUri, null, f, null, null);
    		TextView tv = (TextView) findViewById(R.id.textView1);
			int keyIndex = cc.getColumnIndex("key");
			int valueIndex = cc.getColumnIndex("value");
			cc.moveToFirst();
			//cc.moveToLast();
			String key=cc.getString(keyIndex);
			String value=cc.getString(valueIndex);
			tv.append(key+":"+value+"/n");
			//
    	}*/
    	//System.out.println("local dump");
    }
	public void callPut1(View v)
	{
		ContentValues[] cv = new ContentValues[TEST_CNT];
		for (int i = 0; i < TEST_CNT; i++) {
			cv[i] = new ContentValues();
			cv[i].put(KEY_FIELD, "" + Integer.toString(i));
			cv[i].put(VALUE_FIELD, "Put1" + Integer.toString(i));
		}
		insertToProvider(cv);
	}
	
	public void callPut2(View v)
	{
		ContentValues[] cv = new ContentValues[TEST_CNT];
		for (int i = 0; i < TEST_CNT; i++) {
			cv[i] = new ContentValues();
			cv[i].put(KEY_FIELD, "" + Integer.toString(i));
			cv[i].put(VALUE_FIELD, "Put2" + Integer.toString(i));
		}
		insertToProvider(cv);
	}

	public void callPut3(View v)
	{
		ContentValues[] cv = new ContentValues[TEST_CNT];
		for (int i = 0; i < TEST_CNT; i++) {
			cv[i] = new ContentValues();
			cv[i].put(KEY_FIELD, "" + Integer.toString(i));
			cv[i].put(VALUE_FIELD, "Put3" + Integer.toString(i));
		}
		insertToProvider(cv);
	}
	public void getFiles(View v)
	{
		for(int i=0;i<20;i++)
		{
			Cursor cc=getContentResolver().query(mUri, null, i+"", null, null);
    	
    	if(cc!=null)
    	{
    		if((cc.moveToFirst())){
    		do{
    		int keyIndex = cc.getColumnIndex("key");
			int valueIndex = cc.getColumnIndex("value");
			//cc.moveToFirst();
			Log.v("printing", "values");
			//cc.moveToLast();
			String key=cc.getString(keyIndex);
			String value=cc.getString(valueIndex);
			String re=key+":"+value;
			new displayMessage().execute(re);
			//cc.moveToNext();
    		}while(cc.moveToNext());
    		}
    	}
    	cc.close();
    	cc=null;
    	try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		
	}
	class displayMessage extends AsyncTask<String, String, String>
	{

		@Override
		protected String doInBackground(String... params) 
		{
			return params[0];
		}
		@Override
		protected void onPostExecute(String result) 
		{
			super.onPostExecute(result);
			TextView tv = (TextView) findViewById(R.id.textView1);
			String []kv=result.split(":");
			tv.append("<"+kv[0]+":"+kv[1]+">"+"\n");
					}		
	}
}
